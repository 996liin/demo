#ifndef	__HEADFILE_H_
#define	__HEADFILE_H_

/*
	ע���ײ��h�ļ���Ҫ���Ϸ�
*/

#include "gd32f4xx.h"
#include "systick.h"
#include "queue.h"
#include "at24cxx.h"
#include "usart.h"
#include "timer.h"
#include "flash.h"
#include "iap.h"
#include "iap_flag.h"


#endif


